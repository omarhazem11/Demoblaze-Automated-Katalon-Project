import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.model.FailureHandling as FailureHandling


// --- Step 1: Open Browser ---
WebUI.openBrowser('https://www.demoblaze.com/')

// --- Step 2: Go to About Us section ---
WebUI.click(findTestObject('AboutUs_OR/Page_STORE/AboutUS'))


// --- Step 3: Click the video to play ---
WebUI.click(findTestObject('AboutUs_OR/Page_STORE/div_About us_vjs-poster'))

// --- Step 4: Verify video is playing ---
boolean isPlaying = WebUI.verifyElementVisible(findTestObject('Object Repository/AboutUs_OR/Page_STORE/Page_STORE/video_About us_example-video_html5_api'), FailureHandling.OPTIONAL)

if (isPlaying) {
    KeywordUtil.markPassed('✅ About Us video started playing successfully.')
} else {
    KeywordUtil.markFailed('⚠️ Could not confirm that video is playing (verify manually).')
}

// --- Step 5: Close Browser ---
WebUI.closeBrowser()
