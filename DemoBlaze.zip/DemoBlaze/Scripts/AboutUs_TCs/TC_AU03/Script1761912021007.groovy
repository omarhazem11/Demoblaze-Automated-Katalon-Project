import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.model.FailureHandling as FailureHandling


WebUI.openBrowser('https://www.demoblaze.com/')
WebUI.maximizeWindow()


WebUI.click(findTestObject('AboutUs_OR/Page_STORE/AboutUS'))

WebUI.waitForElementPresent(findTestObject('Object Repository/AboutUs_OR/Page_STORE/div_About us_vjs-poster'), 3)
WebUI.click(findTestObject('AboutUs_OR/Page_STORE/button_Close Modal Dialog_btn btn-secondary'))


boolean modalClosed = WebUI.verifyElementNotVisible(
    findTestObject('AboutUs_OR/Page_STORE/div_About us_vjs-poster'),
    FailureHandling.OPTIONAL
)

if (modalClosed) {
    KeywordUtil.markPassed('✅ Close button closed the About Us modal successfully.')
} else {
    KeywordUtil.markWarning('⚠️ Close button clicked but modal still visible.')
}

WebUI.closeBrowser()
