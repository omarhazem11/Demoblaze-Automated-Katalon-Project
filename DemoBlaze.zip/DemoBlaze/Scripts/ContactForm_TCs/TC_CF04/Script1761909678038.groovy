import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil

WebUI.openBrowser('https://www.demoblaze.com/')

WebUI.click(findTestObject('ContactForm_OR/Page_STORE/contact form'))

WebUI.waitForElementPresent(findTestObject('ContactForm_OR/Page_STORE/Page_STORE/div_New message_modal-body'), 0)

WebUI.setText(findTestObject('ContactForm_OR/Page_STORE/input_Contact Email_recipient-email'), 'omar@@test?')

WebUI.setText(findTestObject('ContactForm_OR/Page_STORE/input_Contact Name_recipient-name'), 'Omar')

WebUI.setText(findTestObject('ContactForm_OR/Page_STORE/textarea_Message_message-text'), 'Hello World')

WebUI.click(findTestObject('ContactForm_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.waitForAlert(0)

String Alert = WebUI.getAlertText()

if (Alert == "Thanks for the message!!"){
	KeywordUtil.markFailed("❌ Contact form submitted with invalid email")
}
else {
	KeywordUtil.markPassed("Contact form cannot submit while having invalid email format: "+ Alert)
}


WebUI.closeBrowser()

