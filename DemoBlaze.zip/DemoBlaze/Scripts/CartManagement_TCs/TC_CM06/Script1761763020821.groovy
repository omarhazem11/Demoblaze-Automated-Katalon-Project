import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import org.openqa.selenium.WebElement

// --- STEP 1️: Open site and log in ---
WebUI.openBrowser('https://demoblaze.com/')
WebUI.maximizeWindow()

WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))
WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')
WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Password_loginpassword'), 'Test123')
WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.verifyTextPresent('Welcome omar_test123', false)
WebUI.delay(2)

// --- STEP 2️: Add two products to cart ---
WebUI.click(findTestObject('ProductBrowsingAndDetails_OR/Page_STORE/Page_STORE/a_360_hrefch'))
WebUI.verifyTextPresent('Nokia lumia 1520', false)
WebUI.click(findTestObject('Object Repository/CartManagement_OR/Page_STORE/a_Product description_btn btn-success btn-lg'))
WebUI.waitForAlert(5)
WebUI.acceptAlert()

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Home'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Laptops'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Macbook pro'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Add to cart'))
WebUI.waitForAlert(5)
WebUI.acceptAlert()

// --- STEP 3️: Open cart and store product names ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

TestObject productNamesObj = new TestObject()
productNamesObj.addProperty("xpath", ConditionType.EQUALS, "//tbody[@id='tbodyid']/tr/td[2]")

List<WebElement> productElementsBefore = WebUiCommonHelper.findWebElements(productNamesObj, 10)
List<String> productsBefore = []
for (WebElement el : productElementsBefore) {
    productsBefore.add(el.getText().trim())
}
println("🛒 Products before logout: " + productsBefore)

// --- STEP 4️: Logout ---
WebUI.click(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/LogOut'))
WebUI.waitForPageLoad(5)
WebUI.verifyTextPresent('Log in', false)
println("✅ Logged out successfully")

// --- STEP 5️: Log in again ---
WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))
WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')
WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Password_loginpassword'), 'Test123')
WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.verifyTextPresent('Welcome omar_test123', false)
WebUI.delay(2)

// --- STEP 6️: Reopen cart and store product names again ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

List<WebElement> productElementsAfter = WebUiCommonHelper.findWebElements(productNamesObj, 10)
List<String> productsAfter = []
for (WebElement el : productElementsAfter) {
    productsAfter.add(el.getText().trim())
}
println("🛒 Products after re-login: " + productsAfter)

// --- STEP 7️⃣: Compare both lists (ignore order but check quantities) ---
def getFrequencyMap = { list ->
    def freq = [:]
    list.each { item ->
        freq[item] = (freq[item] ?: 0) + 1
    }
    return freq
}

def beforeMap = getFrequencyMap(productsBefore)
print(beforeMap)
def afterMap = getFrequencyMap(productsAfter)
print(afterMap)

if (beforeMap == afterMap) {
    KeywordUtil.markPassed("✅ Cart contents persisted after logout/login (same products & quantities, order ignored).")
} else {
    KeywordUtil.markFailed("❌ Cart contents changed after re-login.\nBefore: ${beforeMap}\nAfter: ${afterMap}")
}

// --- STEP 8️⃣: Close browser ---
WebUI.closeBrowser()
