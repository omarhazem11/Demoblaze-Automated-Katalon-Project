import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
import org.openqa.selenium.WebElement

// --- OPEN SITE AND LOGIN ---
WebUI.openBrowser('https://demoblaze.com/')
WebUI.maximizeWindow()

WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))
WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')
WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Password_loginpassword'), 'Test123')
WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.verifyTextPresent('Welcome omar_test123', false)

// --- ADD PRODUCTS ---
WebUI.click(findTestObject('ProductBrowsingAndDetails_OR/Page_STORE/Page_STORE/a_360_hrefch'))
WebUI.verifyTextPresent('Nokia lumia 1520', false)
WebUI.click(findTestObject('Object Repository/CartManagement_OR/Page_STORE/a_Product description_btn btn-success btn-lg'))
WebUI.waitForAlert(5)
WebUI.acceptAlert()

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Home'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Laptops'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Macbook pro'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Add to cart'))
WebUI.waitForAlert(5)
WebUI.acceptAlert()

// --- GO TO CART ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

// --- COUNT PRODUCTS & TOTAL ---
TestObject productRows = new TestObject()
productRows.addProperty("xpath", ConditionType.EQUALS, "//div[6]//table/tbody/tr")
List<WebElement> allProducts = WebUiCommonHelper.findWebElements(productRows, 10)
int totalProducts = allProducts.size()
println("🛒 Total products in cart: " + totalProducts)

int calculatedTotal = 0
for (int i = 1; i <= totalProducts; i++) {
    String xpath = "//div[6]//table/tbody/tr[" + i + "]/td[3]"
    TestObject priceObj = new TestObject()
    priceObj.addProperty("xpath", ConditionType.EQUALS, xpath)
    String priceText = WebUI.getText(priceObj).replaceAll("[^0-9.]", "")
    calculatedTotal += Double.parseDouble(priceText)
}

String priceText2 = WebUI.getText(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/Total')).replaceAll("[^0-9.]", "")
int Realprice = Double.parseDouble(priceText2)
if (calculatedTotal == Realprice) {
    KeywordUtil.markPassed('✅ Total amount correct')
} else {
    KeywordUtil.markFailed('❌ Total amount wrong')
}

// --- STORE PRODUCT NAMES BEFORE LOGOUT ---
TestObject productNamesObj = new TestObject()
productNamesObj.addProperty("xpath", ConditionType.EQUALS, "//div[6]//table/tbody/tr/td[2]")
List<WebElement> productElementsBefore = WebUiCommonHelper.findWebElements(productNamesObj, 10)
List<String> productsBefore = []
for (WebElement el : productElementsBefore) {
    productsBefore.add(el.getText().trim())
}
println("🛒 Products before logout: " + productsBefore)

// --- LOGOUT ---
WebUI.click(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/Logout'))
WebUI.waitForPageLoad(5)
KeywordUtil.logInfo("✅ Logged out successfully")

// --- LOGIN AGAIN ---
WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))
WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')
WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Password_loginpassword'), 'Test123')
WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))
WebUI.verifyTextPresent('Welcome omar_test123', false)
WebUI.delay(2)

// --- REOPEN CART ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

// --- GET PRODUCT NAMES AFTER LOGIN ---
List<WebElement> productElementsAfter = WebUiCommonHelper.findWebElements(productNamesObj, 10)
List<String> productsAfter = []
for (WebElement el : productElementsAfter) {
    productsAfter.add(el.getText().trim())
}
println("🛒 Products after re-login: " + productsAfter)

// --- COMPARE CART CONTENT ---
if (productsBefore.sort() == productsAfter.sort()) {
    KeywordUtil.markPassed("✅ Cart contents persisted after logout/login.")
} else {
    KeywordUtil.markFailed("❌ Cart contents changed after re-login.\nBefore: ${productsBefore}\nAfter: ${productsAfter}")
}

// --- CLOSE BROWSER ---
WebUI.closeBrowser()
