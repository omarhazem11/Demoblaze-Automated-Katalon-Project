import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import com.kms.katalon.core.util.KeywordUtil
import java.net.HttpURLConnection
import java.net.URL

WebUI.openBrowser('https://demoblaze.com/')
WebUI.maximizeWindow()

// Wait for page to load
WebUI.waitForPageLoad(10)
WebUI.delay(2)

// ✅ Use your fixed object
def productImages = findTestObject('Object Repository/ProductBrowsingAndDetails_OR/product_images')
WebUI.waitForElementVisible(productImages, 10)

// Get all image elements
List<WebElement> allImages = WebUI.findWebElements(productImages, 10)
KeywordUtil.logInfo("🖼️ Found ${allImages.size()} product images on the page")

int brokenCount = 0
for (WebElement img : allImages) {
    String src = img.getAttribute('src')

    if (src == null || src.trim().isEmpty()) {
        KeywordUtil.logInfo("⚠️ Image missing src attribute: ${img}")
        brokenCount++
        continue
    }

    URL url = new URL(src)
    HttpURLConnection connection = (HttpURLConnection) url.openConnection()
    connection.setRequestMethod('GET')
    connection.connect()
    int code = connection.getResponseCode()
    connection.disconnect()

    if (code != 200) {
        KeywordUtil.markFailed("❌ Broken image: ${src} (Status ${code})")
        brokenCount++
    } else {
        KeywordUtil.logInfo("✅ Image loaded correctly: ${src}")
    }
}

// --- Final result ---
if (brokenCount > 0) {
    KeywordUtil.markFailed("❌ ${brokenCount} broken or missing images detected.")
} else {
    KeywordUtil.markPassed("✅ All product images loaded successfully.")
}

WebUI.closeBrowser()
