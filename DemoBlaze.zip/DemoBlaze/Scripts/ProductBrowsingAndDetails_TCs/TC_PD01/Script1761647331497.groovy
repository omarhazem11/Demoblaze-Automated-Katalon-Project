import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import com.kms.katalon.core.util.KeywordUtil

// --- Expected products by category ---
Map<String, List<String>> categoryProducts = [
    'Phones'   : ['Samsung galaxy s6', 'Nokia lumia 1520', 'Nexus 6', 'HTC One M9', 'Sony xperia z5','Iphone 6 32gb','Samsung galaxy s7'],
    'Laptops'  : ['Sony vaio i5', 'Sony vaio i7', 'MacBook air', 'MacBook Pro','Dell i7 8gb','2017 Dell 15.6 Inch'],
    'Monitors' : ['Apple monitor 24', 'ASUS Full HD']
]

WebUI.openBrowser('https://demoblaze.com/')
WebUI.maximizeWindow()

// --- LOGIN ---
WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))
WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')
WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Password_loginpassword'), 'Test123')
WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))
WebUI.verifyTextPresent('Welcome omar_test123', false)

// --- VERIFY PRODUCTS BY CATEGORY ---
def categories = [
    'Phones'   : findTestObject('Object Repository/ProductBrowsingAndDetails_OR/Page_STORE/Phones'),
    'Laptops'  : findTestObject('Object Repository/ProductBrowsingAndDetails_OR/Page_STORE/Laptops'),
    'Monitors' : findTestObject('Object Repository/ProductBrowsingAndDetails_OR/Page_STORE/Monitors')
]

categories.each { categoryName, categoryObject ->
    KeywordUtil.logInfo("🔍 Checking category: ${categoryName}")

    try {
        WebUI.click(categoryObject)
        WebUI.delay(2) // wait for products to load

        TestObject productTitles = findTestObject('Object Repository/ProductBrowsingAndDetails_OR/Page_STORE/product_titles')
        WebUI.waitForElementVisible(productTitles, 10)

        List<WebElement> displayedProducts = WebUI.findWebElements(productTitles, 10)
        List<String> productNames = displayedProducts.collect { it.getText().trim() }

        List<String> expected = categoryProducts[categoryName]
        List<String> unexpected = productNames.findAll { !expected.contains(it) }
        List<String> missing = expected.findAll { !productNames.contains(it) }

        if (unexpected || missing) {
            KeywordUtil.markFailed("❌ Category '${categoryName}' verification failed at ${new Date()}")
            KeywordUtil.logInfo("   ✅ Expected Products: ${expected}")
            KeywordUtil.logInfo("   🧾 Displayed Products: ${productNames}")
            if (unexpected) KeywordUtil.markFailed("   🚫 Unexpected Products: ${unexpected}")
            if (missing) KeywordUtil.markFailed("   ⚠️ Missing Products: ${missing}")
        } else {
            KeywordUtil.markPassed("✅ Category '${categoryName}' verified successfully. All products correct.")
        }

    } catch (Exception e) {
        KeywordUtil.markFailed("❗ Error while checking ${categoryName}: ${e.message}")
    }
}

WebUI.closeBrowser()
