import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil

// --- Expected products ---
Map<String, List> categoryProducts = [('Phones') : ['Samsung galaxy s6', 'Nokia lumia 1520', 'Nexus 6', 'HTC One M9', 'Sony xperia z5'
        , 'Iphone 6 32gb', 'Samsung galaxy s7'], ('Laptops') : ['Sony vaio i5', 'Sony vaio i7', 'MacBook air', 'MacBook Pro'
        , 'Dell i7 8gb', '2017 Dell 15.6 Inch'], ('Monitors') : ['Apple monitor 24', 'ASUS Full HD']]

WebUI.openBrowser('https://demoblaze.com/')

WebUI.maximizeWindow()

// --- LOGIN ---
WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))

WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')

WebUI.setText(findTestObject('LogIn_OR/Page_STORE/input_Password_loginpassword'), 'Test123')

WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.verifyTextPresent('Welcome omar_test123', false)

// --- Navigate to Phones category ---
WebUI.click(findTestObject('ProductBrowsingAndDetails_OR/Page_STORE/Phones'))

WebUI.delay(2)

// Helper method to get current displayed product titles
// --- Step 1: Verify first page ---
List<String> displayed = getDisplayedProducts()

KeywordUtil.logInfo("📱 First page phones: $displayed")

List<String> notPhones = displayed.findAll({ 
        !((categoryProducts['Phones']).contains(it))
    })

if (notPhones.isEmpty()) {
    KeywordUtil.markPassed('✅ First page: Only phones are displayed.')
} else {
    KeywordUtil.markFailed("❌ First page contains non-phone items: $notPhones")
}

// --- Step 2: Click Next and check again ---
WebUI.click(findTestObject('ProductBrowsingAndDetails_OR/Page_STORE/button_Previous_next2'))

WebUI.delay(2)

displayed = getDisplayedProducts()

KeywordUtil.logInfo("➡️ After Next - Phones: $displayed")

notPhones = displayed.findAll({ 
        !((categoryProducts['Phones']).contains(it))
    })

if (notPhones.isEmpty()) {
    KeywordUtil.markPassed('✅ Next page: Only phones are displayed.')
} else {
    KeywordUtil.markFailed("❌ Next page contains non-phone items: $notPhones")
}

// --- Step 3: Click Previous and check again ---
WebUI.click(findTestObject('ProductBrowsingAndDetails_OR/Page_STORE/button_790_prev2'))

WebUI.delay(2)

displayed = getDisplayedProducts()

KeywordUtil.logInfo("⬅️ After Previous - Phones: $displayed")

notPhones = displayed.findAll({ 
        !((categoryProducts['Phones']).contains(it))
    })

if (notPhones.isEmpty()) {
    KeywordUtil.markPassed('✅ Previous page: Only phones are displayed.')
} else {
    KeywordUtil.markFailed("❌ Previous page contains non-phone items: $notPhones")
}

WebUI.closeBrowser()

def getDisplayedProducts() {
    def productTitles = findTestObject('ProductBrowsingAndDetails_OR/Page_STORE/product_titles')

    WebUI.waitForElementVisible(productTitles, 10)

    List<WebElement> elements = WebUI.findWebElements(productTitles, 10)

    return elements.collect({ 
            it.getText().trim()
        })
}

