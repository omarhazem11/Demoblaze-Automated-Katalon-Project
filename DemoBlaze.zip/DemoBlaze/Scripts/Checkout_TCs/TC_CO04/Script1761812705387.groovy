import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable
import java.text.SimpleDateFormat

// --- STEP 1️: Open site and log in ---
WebUI.openBrowser('https://demoblaze.com/')

WebUI.maximizeWindow()

WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))

WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')

WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Password_loginpassword'), 'Test123')

WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.verifyTextPresent('Welcome omar_test123', false)

WebUI.delay(2)

// --- STEP 2️: Add  product to cart ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Home'))

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Laptops'))

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Macbook pro'))

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Add to cart'))

WebUI.waitForAlert(5)

WebUI.acceptAlert()

// --- STEP 3️: Open cart
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))

WebUI.waitForPageLoad(10)

// --- STEP 4: click place order
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Place order'))

// --- STEP 5: verify form opens with wait
TestObject placeOrderModal = findTestObject('Object Repository/Checkout_OR/Page_STORE/Page_STORE/div_Place order_modal-body')

WebUI.waitForElementVisible(placeOrderModal, 10)

WebUI.verifyElementVisible(placeOrderModal, FailureHandling.STOP_ON_FAILURE)

// --- STEP 6: fill in the form
WebUI.setText(findTestObject('Object Repository/Checkout_OR/Page_STORE/input_Name_name'), 'Omar Hazem')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Country_country'), 'Egypt')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_City_city'), 'Cairo')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Year_year'), '2027')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Month_month'), '12')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Credit card_card'), '4111 1111 1111 1111')

// --- STEP 7: click Purchase
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Purchase'))

// --- STEP 8: verify message with " Thank you for your purchase!" appear


String Alert = WebUI.getText(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/h2'))
print(Alert)

String Alert2 = WebUI.getText(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/p_Thank you for your purchase_lead text-muted'))
println("Alert Text: " + Alert2)

String alertDate = Alert2.split("Date:")[1].trim()
Date today = new Date()
SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy")  // same format as alert
String realDate = sdf.format(today)


if (Alert.contains('Thank you for your purchase!')) {
	KeywordUtil.markPassed('✅ Order Placed')
	if (alertDate.equals(realDate)) {
		WebUI.comment("✅ Date is correct: " + alertDate)
	} else {
		KeywordUtil.markWarning('❌ Date mismatch! Expected:'  + realDate + ' but found: ' + alertDate)
	}
} else {
	KeywordUtil.markFailed('❌ Something went wrong')
}


// --- STEP 9: Verify cart clears after purchase ---

WebUI.click(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/ok'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

boolean isItemNotPresent = WebUI.verifyElementNotPresent(
    findTestObject('CartManagement_OR/Page_STORE/Page_STORE/product_row'),
    5,
    FailureHandling.OPTIONAL
)



if (isItemNotPresent) {
    KeywordUtil.markPassed('✅ Cart is empty after purchase.')
} else {
    KeywordUtil.markFailed('❌ Cart still contains items after purchase.')
}

// --- STEP 10: Close browser ---
WebUI.closeBrowser()