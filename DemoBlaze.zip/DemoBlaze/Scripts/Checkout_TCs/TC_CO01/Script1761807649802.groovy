import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.model.FailureHandling


// --- STEP 1️: Open site and log in ---
WebUI.openBrowser('https://demoblaze.com/')

WebUI.maximizeWindow()

WebUI.click(findTestObject('LogIn_OR/Page_STORE/a_Cart_login2'))

WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Username_loginusername'), 'omar_test123')

WebUI.setText(findTestObject('Object Repository/Login_OR/Page_STORE/input_Password_loginpassword'), 'Test123')

WebUI.click(findTestObject('LogIn_OR/Page_STORE/button_Close_btn btn-primary'))

WebUI.verifyTextPresent('Welcome omar_test123', false)

WebUI.delay(2)

// --- STEP 2️: Add  product to cart ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Home'))

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Laptops'))

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Macbook pro'))

WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Add to cart'))

WebUI.waitForAlert(5)

WebUI.acceptAlert()

// --- STEP 3️: Open cart 
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))

WebUI.waitForPageLoad(10)

// --- STEP 4: click place order
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Place order'))

// --- STEP 5: verify form opens with wait
TestObject placeOrderModal = findTestObject('Object Repository/Checkout_OR/Page_STORE/Page_STORE/div_Place order_modal-body')
WebUI.waitForElementVisible(placeOrderModal, 10)
WebUI.verifyElementVisible(placeOrderModal, FailureHandling.STOP_ON_FAILURE)

// --- STEP 6: Close browser ---
WebUI.closeBrowser()

