import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.model.FailureHandling as FailureHandling

// --- STEP 1: Open browser and navigate to site ---
WebUI.openBrowser('https://demoblaze.com/')
WebUI.maximizeWindow()

// --- STEP 2: Go to Cart ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

// --- STEP 3: Verify cart is empty ---
boolean isItemNotPresent = WebUI.verifyElementNotPresent(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/product_row'),5)

if (!isItemNotPresent) {
    KeywordUtil.markWarning('⚠️ Cart still has items, clearing it manually or run after purchase test.')
}

// --- STEP 4: Try to click "Place Order" ---
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Place order'))

// --- STEP 5: fill in the form
WebUI.setText(findTestObject('Object Repository/Checkout_OR/Page_STORE/input_Name_name'), 'Omar Hazem')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Country_country'), 'Egypt')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_City_city'), 'Cairo')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Year_year'), '2027')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Month_month'), '12')

WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Credit card_card'), '4111 1111 1111 1111')

// --- STEP 6: click Purchase
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Purchase'))
String Alert = WebUI.getText(findTestObject('Object Repository/CartManagement_OR/Page_STORE/Page_STORE/h2'))

if (Alert.contains('Thank you for your purchase!')) {
	KeywordUtil.markFailed('❌ Empty Order Placed')
} else {
	KeywordUtil.markPassed('✅ Order could not be placed')
}


// --- STEP 7: Close browser ---
WebUI.closeBrowser()
