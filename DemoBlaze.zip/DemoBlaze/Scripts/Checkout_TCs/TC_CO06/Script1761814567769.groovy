import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.model.FailureHandling as FailureHandling

// --- STEP 1: Open browser and navigate to site ---
WebUI.openBrowser('https://demoblaze.com/')
WebUI.maximizeWindow()

// --- STEP 2️: Add product to cart ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Home'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Laptops'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Macbook pro'))
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/Add to cart'))

WebUI.waitForAlert(5)
WebUI.acceptAlert()

// --- STEP 3: Go to Cart ---
WebUI.click(findTestObject('CartManagement_OR/Page_STORE/Page_STORE/cart'))
WebUI.waitForPageLoad(10)

// --- STEP 4: Click "Place Order" ---
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Place order'))

// --- STEP 5: Fill form with invalid data ---
WebUI.setText(findTestObject('Object Repository/Checkout_OR/Page_STORE/input_Name_name'), '123')
WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Country_country'), '567')
WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_City_city'), '789?')
WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Year_year'), '1')
WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Month_month'), '13')
WebUI.setText(findTestObject('Checkout_OR/Page_STORE/input_Credit card_card'), 'Omar')

// --- STEP 6: Click Purchase ---
WebUI.click(findTestObject('Object Repository/Checkout_OR/Page_STORE/Purchase'))

// --- STEP 7: Validate result ---
boolean successMessage = WebUI.verifyTextPresent('Thank you for your purchase!', false, FailureHandling.OPTIONAL)

if (successMessage) {
    KeywordUtil.markFailed('❌ Order was placed with invalid information — this is a bug.')
} else {
    KeywordUtil.markPassed('✅ Order could not be placed with invalid data — validation works correctly.')
}

// --- STEP 8: Close browser ---
WebUI.closeBrowser()
