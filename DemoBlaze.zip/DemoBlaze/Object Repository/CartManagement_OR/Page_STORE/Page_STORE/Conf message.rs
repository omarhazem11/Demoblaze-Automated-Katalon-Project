<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conf message</name>
   <tag></tag>
   <elementGuidId>ea4c9f5b-d470-4293-a573-013e4e4e1dc8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[10]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sweet-alert.showSweetAlert.visible</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Thank you for your purchase! Id: 2303674Amount: 0 USDCard Number: 9Name: jDate: &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>eefe05e7-00d5-4488-84f6-c4dbba020752</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sweet-alert  showSweetAlert visible</value>
      <webElementGuid>d6ddc8bf-9190-43ee-a86f-811236a8a828</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
      <webElementGuid>053c4fbc-126c-41fa-ba8b-bc8927ec1320</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-has-cancel-button</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>19eaf9da-d742-44be-ad16-5c6cbeb20bee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-has-confirm-button</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>e60ffe81-da98-4e3c-befc-5c05d4b261ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-allow-outside-click</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>a14f2f60-6870-4332-bf10-0bbe0d111eb5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-has-done-function</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>70db4dee-adf2-4dbf-a1eb-e727ae653bde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-animation</name>
      <type>Main</type>
      <value>pop</value>
      <webElementGuid>51d363fd-4a6d-45a0-9371-4c23f1297789</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      
        
        
      
    
      
      
    
      
      

      
      
    Thank you for your purchase!
    Id: 2303674Amount: 0 USDCard Number: 9Name: jDate: 30/9/2025
    
      
      
         Not valid
      
    
      Cancel
      
        OK
          
          
          
        
      
    </value>
      <webElementGuid>a8c0d246-c911-4799-bf90-11fc7051b8fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open stop-scrolling&quot;]/div[@class=&quot;sweet-alert  showSweetAlert visible&quot;]</value>
      <webElementGuid>24b6a7d0-7c6a-452d-9573-a81f44cde18b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='`'])[1]/following::div[3]</value>
      <webElementGuid>b5a4e321-5cd8-4a6e-9260-3cdf9d094fee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]</value>
      <webElementGuid>00c3e5d0-3ecc-46aa-af87-010a8d8f7ffe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
      
        
        
      
    
      
      
    
      
      

      
      
    Thank you for your purchase!
    Id: 2303674Amount: 0 USDCard Number: 9Name: jDate: 30/9/2025
    
      
      
         Not valid
      
    
      Cancel
      
        OK
          
          
          
        
      
    ' or . = '
      
        
        
      
    
      
      
    
      
      

      
      
    Thank you for your purchase!
    Id: 2303674Amount: 0 USDCard Number: 9Name: jDate: 30/9/2025
    
      
      
         Not valid
      
    
      Cancel
      
        OK
          
          
          
        
      
    ')]</value>
      <webElementGuid>93cfcb88-6e8f-4987-b3ed-dfa72efbceba</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
