<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Thank you for your purchase_lead text-muted</name>
   <tag></tag>
   <elementGuidId>2a4bbef7-741e-49f3-9e7f-7aaf8d4539be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Thank you for your purchase!'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.lead.text-muted</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Id: 6617961Amount: 0 USDCard Number: 1Name: 1Date: 30/9/2025&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>62764580-ef08-4e73-bb4b-27fca65901eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>lead text-muted </value>
      <webElementGuid>0d919877-bb1c-4dfb-8c4b-bd16f4a87ff9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Id: 6617961Amount: 0 USDCard Number: 1Name: 1Date: 30/9/2025</value>
      <webElementGuid>30b18a77-2da3-495f-91b7-53bd1cc86c5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open stop-scrolling&quot;]/div[@class=&quot;sweet-alert  showSweetAlert visible&quot;]/p[@class=&quot;lead text-muted&quot;]</value>
      <webElementGuid>bda57fd3-f978-445c-bfa0-d324eab2d132</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thank you for your purchase!'])[1]/following::p[1]</value>
      <webElementGuid>7edaac20-0d7c-470b-8c38-5798a3633733</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='`'])[1]/following::p[1]</value>
      <webElementGuid>b443c164-6256-4dbd-97e1-a0137775b8a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not valid'])[1]/preceding::p[1]</value>
      <webElementGuid>c812f5d7-ea0d-4c48-a492-9f9cd9120122</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/preceding::p[1]</value>
      <webElementGuid>5779a9c8-3b19-4d19-a2e0-960bc0ab5564</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Id: 6617961']/parent::*</value>
      <webElementGuid>6f3d2ea3-2e3c-41cb-b00f-03ce4345d9e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/p</value>
      <webElementGuid>2b963175-2248-4281-8beb-5de851b5fc6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Id: 6617961Amount: 0 USDCard Number: 1Name: 1Date: 30/9/2025' or . = 'Id: 6617961Amount: 0 USDCard Number: 1Name: 1Date: 30/9/2025')]</value>
      <webElementGuid>2a4bf337-92f0-4c0a-b921-b6db4f7d1a90</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
