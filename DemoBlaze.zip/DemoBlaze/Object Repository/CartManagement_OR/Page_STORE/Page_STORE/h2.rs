<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2</name>
   <tag></tag>
   <elementGuidId>02dc3c88-eb06-4c5a-a9fc-15f23e8e4d17</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='PRODUCT STORE'])[2]/following::h2[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sweet-alert.showSweetAlert.visible > h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Thank you for your purchase!&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>823a2efa-6747-403d-acc2-9d057032e77c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Thank you for your purchase!</value>
      <webElementGuid>342a1aef-0444-4dec-a3a3-2a7ebaaa1d0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open stop-scrolling&quot;]/div[@class=&quot;sweet-alert  showSweetAlert visible&quot;]/h2[1]</value>
      <webElementGuid>57cbfce7-a11c-4255-a5e9-0e3003106d41</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PRODUCT STORE'])[2]/following::h2[1]</value>
      <webElementGuid>dd48a092-a891-4a50-bc42-81de7cdf48d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get in Touch'])[1]/following::h2[1]</value>
      <webElementGuid>488634cd-77b3-43e0-a134-667fdd127493</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not valid'])[1]/preceding::h2[1]</value>
      <webElementGuid>4a9bcbb1-256f-41fe-874a-082dd31d56c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/preceding::h2[1]</value>
      <webElementGuid>4e2b5416-3ba6-44e8-b9e3-d8f2b6e761c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Thank you for your purchase!']/parent::*</value>
      <webElementGuid>353f0ef5-afb8-46d5-9e73-c357068467f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/h2</value>
      <webElementGuid>62cd11b4-21a3-4739-90f4-fb524bec1082</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Thank you for your purchase!' or . = 'Thank you for your purchase!')]</value>
      <webElementGuid>08b5e987-5ad6-49bf-b5ae-21f17fb4c87c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
