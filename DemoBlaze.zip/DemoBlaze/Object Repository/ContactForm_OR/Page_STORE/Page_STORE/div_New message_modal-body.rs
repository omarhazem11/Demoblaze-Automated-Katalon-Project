<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_New message_modal-body</name>
   <tag></tag>
   <elementGuidId>5dc637cc-0879-4241-8bcf-2158d4143ad7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='exampleModal']/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Contact Email: Contact Name: Message:&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b1ca2618-72a6-4344-883b-6ced5878ada2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-body</value>
      <webElementGuid>bd311596-bc24-4826-bbeb-adc24300f8b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
          
            
              Contact Email:
              
            
            
              Contact Name:
              
            
            
              Message:
              
            
          
        </value>
      <webElementGuid>25f74a28-225d-47f0-aa0c-97d9f5bf79ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;exampleModal&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]</value>
      <webElementGuid>6662de2f-c52e-4483-b7d6-753e55d8435b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='exampleModal']/div/div/div[2]</value>
      <webElementGuid>1fb57f89-0327-4419-9eaa-70a1825156f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New message'])[1]/following::div[1]</value>
      <webElementGuid>392cdf3f-18b9-4de2-bdf3-3dc27c87c2ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]</value>
      <webElementGuid>c0f50564-8bff-49b4-ac46-5b1e08479463</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
          
            
              Contact Email:
              
            
            
              Contact Name:
              
            
            
              Message:
              
            
          
        ' or . = '
          
            
              Contact Email:
              
            
            
              Contact Name:
              
            
            
              Message:
              
            
          
        ')]</value>
      <webElementGuid>00e0249a-d10f-4345-b4e8-8ae7f6af3917</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
