<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Place order_modal-body</name>
   <tag></tag>
   <elementGuidId>ff33de40-b01b-4534-ba58-f714d9e8dc12</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='orderModal']/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#orderModal > div.modal-dialog > div.modal-content > div.modal-body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Total: Name: Country: City: Credit card: Month: Year:&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cd995af5-54ef-4f7a-a025-45802cb12bb0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-body</value>
      <webElementGuid>21f6f778-0bff-49b3-89e4-5363034aa86f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
          
            Total:
            
              Name:
              
            
            
              Country:
              
            
            
              City:
              
            
            
              Credit card:
              
            
            
              Month:
              
            
            
              Year:
              
            
            
              
            
          
        </value>
      <webElementGuid>dea5caab-02b5-427c-932b-f5c2d7c00940</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;orderModal&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]</value>
      <webElementGuid>d2ae0ae5-ba9f-4363-8fbd-7bc3cad18ad0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='orderModal']/div/div/div[2]</value>
      <webElementGuid>73033b4a-32d4-4afc-902c-d6edc95dfc56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Place order'])[1]/following::div[1]</value>
      <webElementGuid>baf36d68-477f-4318-ac6f-2d951badf927</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[2]/following::div[5]</value>
      <webElementGuid>02ac0714-9d80-4a8e-a186-5a71fe4c53b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div[2]</value>
      <webElementGuid>5702a128-b65f-4d9d-b278-24ed6d4fce13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
          
            Total:
            
              Name:
              
            
            
              Country:
              
            
            
              City:
              
            
            
              Credit card:
              
            
            
              Month:
              
            
            
              Year:
              
            
            
              
            
          
        ' or . = '
          
            Total:
            
              Name:
              
            
            
              Country:
              
            
            
              City:
              
            
            
              Credit card:
              
            
            
              Month:
              
            
            
              Year:
              
            
            
              
            
          
        ')]</value>
      <webElementGuid>3b839608-433b-4b90-8116-7adf1849a5e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
